import 'package:flutter/material.dart';

class InputFiealdWidget extends StatelessWidget {
  const InputFiealdWidget({
    super.key,
    required this.title,
    required this.amount,
    required this.add,
  });

  final TextEditingController title;
  final TextEditingController amount;
  final Function add;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
          TextField(
            controller: title,
            decoration: const InputDecoration(
                labelText: "Title", hintText: "enter a title"),
          ),
          TextField(
            controller: amount,
            decoration: const InputDecoration(
                labelText: "Amount", hintText: "enter an amount"),
          ),
          FilledButton(
              onPressed: () {
                add();
              },
              child: const Text("Add"))
        ]),
      ),
    );
  }
}
