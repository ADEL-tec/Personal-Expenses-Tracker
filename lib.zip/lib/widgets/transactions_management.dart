import 'package:flutter/material.dart';

import '../models/transaction.dart';
import 'input_field_widget.dart';
import 'transactions_list.dart';

class TransactionsMAnagement extends StatefulWidget {
  const TransactionsMAnagement({super.key});

  @override
  State<TransactionsMAnagement> createState() => _TransactionsMAnagementState();
}

class _TransactionsMAnagementState extends State<TransactionsMAnagement> {
  final _titleController = TextEditingController();
  final _amountController = TextEditingController();

  final List<Transaction> _transactions = [
    Transaction(id: "t1", title: "title1", amount: 39.99, date: DateTime.now()),
    Transaction(id: "t2", title: "title2", amount: 5.99, date: DateTime.now()),
    Transaction(
        id: "t3", title: "title3", amount: 100.99, date: DateTime.now()),
  ];

  void _add() {
    setState(() {
      _transactions.add(Transaction(
        id: DateTime.now().toString(),
        title: _titleController.text,
        amount: double.parse(_amountController.text),
        date: DateTime.now(),
      ));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        InputFiealdWidget(
            title: _titleController, amount: _amountController, add: _add),
        TransactionsList(_transactions),
      ],
    );
  }
}
