import 'package:flutter/material.dart';

import '../models/transaction.dart';
import 'transaction_card.dart';

class TransactionsList extends StatelessWidget {
  TransactionsList(
    this.transactions, {
    super.key,
  });

  final List<Transaction> transactions;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: transactions.map((transaction) {
            return TransactionCard(transaction: transaction);
          }).toList(),
        ),
      ),
    );
  }
}
